/*/////////////////////////////////////////////////////////////////////////
// This file is part of the
//  _______                   _               ______  
// (_______)                 | |             (_____ \ 
//  _____  ____  _____   ___ | |__   _   _     ____) )
// |  ___)/ ___)| ___ | /___)|  _ \ | | | |   / ____/ 
// | |   | |    | ____||___ || | | || |_| |  | (_____ 
// |_|   |_|    |_____)(___/ |_| |_| \__  |  |_______)
//                                  (____/            
//                                          Yii theme
//
// Ported from the original Wordpress Freshy 2 theme:
// http://www.jide.fr/english/downloads/freshy2
//
// Licensed under the GPL, like the original theme
// Copyleft 2011 - Jacob 'jacmoe' Moen @ http://www.jacmoe.dk/
/////////////////////////////////////////////////////////////////////////*/

Requirements: 
-----------------
Freshy2 requires a custom menu called Freshy2Menu.php provided in the theme zip file.
Copy it to your protected/components directory before using the theme.

The contents of the zip file should be unzipped in your themes directory as usual.

See views/layouts/main.php as you might want to customize the style.

This theme could do with a page with sample markup, to show you what the theme is able to do, but maybe later. :)
Study the style sheets - it's very specific to Wordpress, of course.

Some global Yii-related styling went into css/yii_style.css.

Cheers

Jacob 'jacmoe' Moen